
import re

import discord
from discord import app_commands
from discord.ext import commands

from core.database import db
from core.embeds import AragogEmbeds
from core.logger import aragog_logger


class TriggerCommands(commands.Cog):
    trigger = app_commands.Group(
        name="trigger",
        description="Manage custom Aragog AI triggers for this server."
    )

    MAX_TRIGGERS = 25
    MAX_TRIGGER_LENGTH = 40

    BUILT_IN_TRIGGERS = {
        "aragog",
        "utils"
    }

    def normalize_trigger(self, phrase: str) -> str:
        return " ".join(phrase.strip().split()).lower()

    def valid_trigger(self, phrase: str) -> bool:
        if not phrase:
            return False

        if len(phrase) < 2 or len(phrase) > self.MAX_TRIGGER_LENGTH:
            return False

        if phrase in self.BUILT_IN_TRIGGERS:
            return False

        # Prevent custom triggers from being only punctuation.
        if not re.search(r"[a-zA-Z0-9]", phrase):
            return False

        return True

    async def admin_check(self, interaction: discord.Interaction) -> bool:
        if interaction.guild is None:
            return False

        permissions = interaction.user.guild_permissions
        return permissions.administrator

    async def send_embed(
        self,
        interaction: discord.Interaction,
        embed: discord.Embed
    ):
        await interaction.response.send_message(
            embed=embed,
            ephemeral=True
        )

    # --------------------------------------------------
    # ADD TRIGGER
    # --------------------------------------------------

    @trigger.command(
        name="add",
        description="Add a custom word or phrase that activates Aragog."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(
        phrase="The word or phrase that should activate Aragog."
    )
    async def add_trigger(
        self,
        interaction: discord.Interaction,
        phrase: app_commands.Range[str, 2, 40]
    ):

        normalized = self.normalize_trigger(phrase)

        if not self.valid_trigger(normalized):
            embed = AragogEmbeds.error(
                "Invalid Trigger",
                "Choose a valid trigger containing letters or numbers. "
                "Built-in triggers are already reserved."
            )
            await self.send_embed(interaction, embed)
            return

        guild_id = interaction.guild.id

        existing = await db.fetchone(
            """
            SELECT id
            FROM ai_custom_triggers
            WHERE guild_id = ? AND trigger_text = ?
            """,
            (guild_id, normalized)
        )

        if existing:
            embed = AragogEmbeds.warning(
                "Trigger Already Exists",
                f"`{normalized}` is already configured for this server."
            )
            await self.send_embed(interaction, embed)
            return

        count = await db.fetchone(
            """
            SELECT COUNT(*) AS total
            FROM ai_custom_triggers
            WHERE guild_id = ?
            """,
            (guild_id,)
        )

        if count and count["total"] >= self.MAX_TRIGGERS:
            embed = AragogEmbeds.error(
                "Trigger Limit Reached",
                f"This server can have a maximum of "
                f"{self.MAX_TRIGGERS} custom triggers."
            )
            await self.send_embed(interaction, embed)
            return

        try:
            await db.execute(
                """
                INSERT INTO ai_custom_triggers
                    (guild_id, trigger_text, created_by)
                VALUES (?, ?, ?)
                """,
                (
                    guild_id,
                    normalized,
                    interaction.user.id
                )
            )

            embed = AragogEmbeds.success(
                "Custom Trigger Added",
                f"Aragog will now respond when someone uses "
                f"`{normalized}` in this server."
            )

            embed.add_field(
                name="TRIGGER",
                value=f"`{normalized}`",
                inline=True
            )

            embed.add_field(
                name="ADDED BY",
                value=interaction.user.mention,
                inline=True
            )

            await self.send_embed(interaction, embed)

            aragog_logger.info(
                "Custom AI trigger added in guild %s.",
                guild_id
            )

        except Exception as error:
            aragog_logger.error(
                "Could not add custom trigger: %s",
                type(error).__name__
            )

            embed = AragogEmbeds.error(
                "Trigger Not Added",
                "Something went wrong while saving this trigger."
            )
            await self.send_embed(interaction, embed)

    # --------------------------------------------------
    # REMOVE TRIGGER
    # --------------------------------------------------

    @trigger.command(
        name="remove",
        description="Remove a custom Aragog AI trigger."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(
        phrase="The custom trigger you want to remove."
    )
    async def remove_trigger(
        self,
        interaction: discord.Interaction,
        phrase: app_commands.Range[str, 2, 40]
    ):

        normalized = self.normalize_trigger(phrase)

        guild_id = interaction.guild.id

        existing = await db.fetchone(
            """
            SELECT id
            FROM ai_custom_triggers
            WHERE guild_id = ? AND trigger_text = ?
            """,
            (guild_id, normalized)
        )

        if not existing:
            embed = AragogEmbeds.error(
                "Trigger Not Found",
                f"`{normalized}` is not a custom trigger in this server."
            )
            await self.send_embed(interaction, embed)
            return

        try:
            await db.execute(
                """
                DELETE FROM ai_custom_triggers
                WHERE guild_id = ? AND trigger_text = ?
                """,
                (guild_id, normalized)
            )

            embed = AragogEmbeds.success(
                "Trigger Removed",
                f"`{normalized}` has been removed from this server."
            )

            embed.add_field(
                name="REMOVED BY",
                value=interaction.user.mention,
                inline=True
            )

            await self.send_embed(interaction, embed)

            aragog_logger.info(
                "Custom AI trigger removed in guild %s.",
                guild_id
            )

        except Exception as error:
            aragog_logger.error(
                "Could not remove custom trigger: %s",
                type(error).__name__
            )

            embed = AragogEmbeds.error(
                "Trigger Not Removed",
                "Something went wrong while removing this trigger."
            )
            await self.send_embed(interaction, embed)

    # --------------------------------------------------
    # LIST TRIGGERS
    # --------------------------------------------------

    @trigger.command(
        name="list",
        description="Show all custom Aragog AI triggers for this server."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def list_triggers(
        self,
        interaction: discord.Interaction
    ):

        rows = await db.fetchall(
            """
            SELECT trigger_text, created_by
            FROM ai_custom_triggers
            WHERE guild_id = ?
            ORDER BY trigger_text COLLATE NOCASE ASC
            """,
            (interaction.guild.id,)
        )

        embed = AragogEmbeds.info(
            "Custom AI Triggers",
            "These custom triggers activate Aragog in this server."
        )

        embed.add_field(
            name="BUILT-IN TRIGGERS",
            value="`@Aragog`  •  `aragog`  •  `utils`",
            inline=False
        )

        if not rows:
            embed.add_field(
                name="CUSTOM TRIGGERS",
                value="No custom triggers have been added yet.",
                inline=False
            )
        else:
            trigger_list = "\n".join(
                f"• `{row['trigger_text']}`"
                for row in rows
            )

            embed.add_field(
                name=f"CUSTOM TRIGGERS ({len(rows)}/{self.MAX_TRIGGERS})",
                value=trigger_list[:1024],
                inline=False
            )

        await self.send_embed(interaction, embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(TriggerCommands(bot))

    aragog_logger.info(
        "Custom AI trigger commands loaded."
    )
