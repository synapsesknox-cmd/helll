
import discord
from discord import app_commands
from discord.ext import commands

from core.database import db
from core.embeds import AragogEmbeds
from core.logger import aragog_logger


class AISettings(commands.Cog):

    ai = app_commands.Group(
        name="ai",
        description="Manage Aragog AI settings."
    )

    channel = app_commands.Group(
        name="channel",
        description="Configure the AI response channel."
    )

    prompt = app_commands.Group(
        name="prompt",
        description="Configure this server's AI personality."
    )

    ai.add_command(channel)
    ai.add_command(prompt)

    MAX_PROMPT_LENGTH = 1500

    # --------------------------------------------------
    # COMMON HELPERS
    # --------------------------------------------------

    async def save_setting(
        self,
        guild_id: int,
        column: str,
        value
    ):
        """Safely update an allowed guild setting."""

        allowed_columns = {
            "ai_enabled",
            "ai_channel_id",
            "custom_prompt"
        }

        if column not in allowed_columns:
            raise ValueError("Unsupported setting.")

        await db.execute(
            f"""
            INSERT INTO guild_settings (guild_id, {column})
            VALUES (?, ?)
            ON CONFLICT(guild_id)
            DO UPDATE SET {column} = excluded.{column}
            """,
            (guild_id, value)
        )

    async def send(
        self,
        interaction: discord.Interaction,
        embed: discord.Embed
    ):
        if interaction.response.is_done():
            await interaction.followup.send(
                embed=embed,
                ephemeral=True
            )
        else:
            await interaction.response.send_message(
                embed=embed,
                ephemeral=True
            )

    async def server_check(
        self,
        interaction: discord.Interaction
    ) -> bool:

        if interaction.guild is None:
            return False

        permissions = interaction.user.guild_permissions

        return bool(permissions.administrator)

    async def get_settings(self, guild_id: int):
        return await db.fetchone(
            """
            SELECT ai_enabled, ai_channel_id, custom_prompt
            FROM guild_settings
            WHERE guild_id = ?
            """,
            (guild_id,)
        )

    # --------------------------------------------------
    # ENABLE AI
    # --------------------------------------------------

    @ai.command(
        name="enable",
        description="Enable Aragog AI in this server."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def enable(
        self,
        interaction: discord.Interaction
    ):

        try:
            await self.save_setting(
                interaction.guild.id,
                "ai_enabled",
                1
            )

            embed = AragogEmbeds.success(
                "AI Enabled",
                "Aragog AI has been enabled for this server."
            )

            embed.add_field(
                name="SERVER",
                value=interaction.guild.name,
                inline=True
            )

            embed.add_field(
                name="UPDATED BY",
                value=interaction.user.mention,
                inline=True
            )

            await self.send(interaction, embed)

        except Exception as error:
            aragog_logger.error(
                "AI enable failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Update Failed",
                    "Could not enable AI right now."
                )
            )

    # --------------------------------------------------
    # DISABLE AI
    # --------------------------------------------------

    @ai.command(
        name="disable",
        description="Disable Aragog AI in this server."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def disable(
        self,
        interaction: discord.Interaction
    ):

        try:
            await self.save_setting(
                interaction.guild.id,
                "ai_enabled",
                0
            )

            embed = AragogEmbeds.warning(
                "AI Disabled",
                "Aragog AI has been disabled for this server."
            )

            embed.add_field(
                name="UPDATED BY",
                value=interaction.user.mention,
                inline=True
            )

            await self.send(interaction, embed)

        except Exception as error:
            aragog_logger.error(
                "AI disable failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Update Failed",
                    "Could not disable AI right now."
                )
            )

    # --------------------------------------------------
    # SET AI CHANNEL
    # --------------------------------------------------

    @channel.command(
        name="set",
        description="Choose the channel where Aragog responds."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(
        target="The text channel where Aragog should respond."
    )
    async def set_channel(
        self,
        interaction: discord.Interaction,
        target: discord.TextChannel
    ):

        if target.guild.id != interaction.guild.id:
            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Invalid Channel",
                    "Choose a text channel from this server."
                )
            )
            return

        try:
            await self.save_setting(
                interaction.guild.id,
                "ai_channel_id",
                target.id
            )

            embed = AragogEmbeds.success(
                "AI Channel Updated",
                f"Aragog will now respond to its triggers in {target.mention}."
            )

            embed.add_field(
                name="UPDATED BY",
                value=interaction.user.mention,
                inline=True
            )

            await self.send(interaction, embed)

        except Exception as error:
            aragog_logger.error(
                "AI channel update failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Channel Update Failed",
                    "Could not update the AI channel."
                )
            )

    # --------------------------------------------------
    # REMOVE AI CHANNEL RESTRICTION
    # --------------------------------------------------

    @channel.command(
        name="remove",
        description="Allow AI triggers in all server channels."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def remove_channel(
        self,
        interaction: discord.Interaction
    ):

        try:
            await self.save_setting(
                interaction.guild.id,
                "ai_channel_id",
                None
            )

            await self.send(
                interaction,
                AragogEmbeds.success(
                    "Channel Restriction Removed",
                    "Aragog can now respond to its triggers in all channels."
                )
            )

        except Exception as error:
            aragog_logger.error(
                "AI channel removal failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Update Failed",
                    "Could not remove the AI channel restriction."
                )
            )

    # --------------------------------------------------
    # VIEW AI CHANNEL
    # --------------------------------------------------

    @channel.command(
        name="view",
        description="View the currently configured AI channel."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def view_channel(
        self,
        interaction: discord.Interaction
    ):

        try:
            settings = await self.get_settings(
                interaction.guild.id
            )

            channel_id = (
                settings["ai_channel_id"]
                if settings else None
            )

            if channel_id:
                target = interaction.guild.get_channel(channel_id)

                value = (
                    target.mention
                    if isinstance(target, discord.TextChannel)
                    else f"Configured channel ID: `{channel_id}`"
                )
            else:
                value = "All server channels"

            embed = AragogEmbeds.info(
                "AI Channel Configuration",
                f"**Response location:** {value}"
            )

            await self.send(interaction, embed)

        except Exception as error:
            aragog_logger.error(
                "AI channel lookup failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Lookup Failed",
                    "Could not retrieve the AI channel."
                )
            )

    # --------------------------------------------------
    # SET SERVER AI PROMPT
    # --------------------------------------------------

    @prompt.command(
        name="set",
        description="Set custom AI instructions for this server."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(
        instructions="Describe how Aragog should behave in this server."
    )
    async def set_prompt(
        self,
        interaction: discord.Interaction,
        instructions: app_commands.Range[
            str, 1, MAX_PROMPT_LENGTH
        ]
    ):

        instructions = instructions.strip()

        if not instructions:
            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Empty Instructions",
                    "Please provide valid AI instructions."
                )
            )
            return

        try:
            await self.save_setting(
                interaction.guild.id,
                "custom_prompt",
                instructions
            )

            embed = AragogEmbeds.success(
                "Server AI Instructions Updated",
                "The server's custom AI instructions have been saved."
            )

            embed.add_field(
                name="INSTRUCTIONS",
                value=(
                    instructions[:1000] + "..."
                    if len(instructions) > 1000
                    else instructions
                ),
                inline=False
            )

            embed.add_field(
                name="UPDATED BY",
                value=interaction.user.mention,
                inline=True
            )

            await self.send(interaction, embed)

        except Exception as error:
            aragog_logger.error(
                "Server AI prompt update failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Prompt Update Failed",
                    "Could not save the custom AI instructions."
                )
            )

    # --------------------------------------------------
    # RESET SERVER AI PROMPT
    # --------------------------------------------------

    @prompt.command(
        name="reset",
        description="Reset server AI instructions to Aragog's default."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def reset_prompt(
        self,
        interaction: discord.Interaction
    ):

        try:
            await self.save_setting(
                interaction.guild.id,
                "custom_prompt",
                None
            )

            await self.send(
                interaction,
                AragogEmbeds.success(
                    "AI Instructions Reset",
                    "This server now uses Aragog's default AI personality."
                )
            )

        except Exception as error:
            aragog_logger.error(
                "Server AI prompt reset failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Reset Failed",
                    "Could not reset the server's AI instructions."
                )
            )

    # --------------------------------------------------
    # AI STATUS
    # --------------------------------------------------

    @ai.command(
        name="status",
        description="View Aragog AI settings for this server."
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def status(
        self,
        interaction: discord.Interaction
    ):

        try:
            settings = await self.get_settings(
                interaction.guild.id
            )

            enabled = (
                bool(settings["ai_enabled"])
                if settings else True
            )

            channel_id = (
                settings["ai_channel_id"]
                if settings else None
            )

            custom_prompt = (
                settings["custom_prompt"]
                if settings else None
            )

            channel = interaction.guild.get_channel(channel_id) if channel_id else None

            embed = AragogEmbeds.info(
                "Aragog AI Settings",
                "Current AI configuration for this server."
            )

            embed.add_field(
                name="AI STATUS",
                value="Enabled" if enabled else "Disabled",
                inline=True
            )

            embed.add_field(
                name="RESPONSE CHANNEL",
                value=channel.mention if channel else (
                    "All channels" if not channel_id
                    else f"Channel ID: `{channel_id}`"
                ),
                inline=True
            )

            embed.add_field(
                name="CUSTOM INSTRUCTIONS",
                value="Configured" if custom_prompt else "Default personality",
                inline=True
            )

            await self.send(interaction, embed)

        except Exception as error:
            aragog_logger.error(
                "AI status lookup failed: %s",
                type(error).__name__
            )

            await self.send(
                interaction,
                AragogEmbeds.error(
                    "Status Unavailable",
                    "Could not retrieve AI settings."
                )
            )


async def setup(bot: commands.Bot):
    await bot.add_cog(AISettings())

    aragog_logger.info(
        "Server AI settings commands loaded."
    )
