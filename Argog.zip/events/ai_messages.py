
import re
from datetime import datetime, timezone

import discord
from discord.ext import commands

from core.ai_engine import ai_engine
from core.ai_fallback import ai_fallback
from core.database import db
from core.logger import aragog_logger


class AIMessages(commands.Cog):

    BRAND = "🔥 Aragog • AI Assistant"
    EMBED_COLOR = 0x367BFF

    MAX_HISTORY_MESSAGES = 20
    MAX_EMBED_CHUNK = 3800

    BUILT_IN_TRIGGERS = (
        "aragog",
        "utils",
    )

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # --------------------------------------------------
    # DATABASE STORAGE
    # --------------------------------------------------

    async def ensure_storage(self):

        await db.execute("""
            CREATE TABLE IF NOT EXISTS ai_conversation_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER,
                channel_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ai_conversation_lookup
            ON ai_conversation_messages (
                guild_id,
                channel_id,
                user_id,
                id
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS ai_custom_triggers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                trigger_text TEXT NOT NULL COLLATE NOCASE,
                created_by INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, trigger_text)
            )
        """)

    # --------------------------------------------------
    # CONVERSATION MEMORY
    # --------------------------------------------------

    async def load_history(
        self,
        guild_id: int | None,
        channel_id: int,
        user_id: int
    ) -> list[dict]:

        rows = await db.fetchall(
            """
            SELECT role, content
            FROM ai_conversation_messages
            WHERE guild_id IS ?
            AND channel_id = ?
            AND user_id = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (
                guild_id,
                channel_id,
                user_id,
                self.MAX_HISTORY_MESSAGES
            )
        )

        rows = list(reversed(rows))

        return [
            {
                "role": row["role"],
                "content": row["content"]
            }
            for row in rows
        ]

    async def save_exchange(
        self,
        guild_id: int | None,
        channel_id: int,
        user_id: int,
        user_message: str,
        assistant_message: str
    ):

        await db.execute(
            """
            INSERT INTO ai_conversation_messages
                (guild_id, channel_id, user_id, role, content)
            VALUES (?, ?, ?, 'user', ?)
            """,
            (
                guild_id,
                channel_id,
                user_id,
                user_message
            )
        )

        await db.execute(
            """
            INSERT INTO ai_conversation_messages
                (guild_id, channel_id, user_id, role, content)
            VALUES (?, ?, ?, 'assistant', ?)
            """,
            (
                guild_id,
                channel_id,
                user_id,
                assistant_message
            )
        )

        await db.execute(
            """
            DELETE FROM ai_conversation_messages
            WHERE id IN (
                SELECT id
                FROM ai_conversation_messages
                WHERE guild_id IS ?
                AND channel_id = ?
                AND user_id = ?
                ORDER BY id DESC
                LIMIT -1 OFFSET ?
            )
            """,
            (
                guild_id,
                channel_id,
                user_id,
                self.MAX_HISTORY_MESSAGES
            )
        )

    # --------------------------------------------------
    # CUSTOM TRIGGERS
    # --------------------------------------------------

    async def get_custom_triggers(
        self,
        guild_id: int | None
    ) -> list[str]:

        if guild_id is None:
            return []

        rows = await db.fetchall(
            """
            SELECT trigger_text
            FROM ai_custom_triggers
            WHERE guild_id = ?
            ORDER BY LENGTH(trigger_text) DESC
            """,
            (guild_id,)
        )

        return [
            row["trigger_text"].strip()
            for row in rows
            if row["trigger_text"]
            and row["trigger_text"].strip()
        ]

    # --------------------------------------------------
    # SERVER AI SETTINGS
    # --------------------------------------------------

    async def is_ai_enabled(
        self,
        message: discord.Message
    ) -> bool:

        if message.guild is None:
            return True

        settings = await db.fetchone(
            """
            SELECT ai_enabled, ai_channel_id
            FROM guild_settings
            WHERE guild_id = ?
            """,
            (message.guild.id,)
        )

        if settings is None:
            return True

        if not settings["ai_enabled"]:
            return False

        channel_id = settings["ai_channel_id"]

        if channel_id and message.channel.id != channel_id:
            return False

        return True

    # --------------------------------------------------
    # REPLY DETECTION
    # --------------------------------------------------

    async def is_reply_to_aragog(
        self,
        message: discord.Message
    ) -> bool:

        if not self.bot.user or not message.reference:
            return False

        reference = message.reference

        if not reference.message_id:
            return False

        referenced_message = reference.resolved

        if isinstance(referenced_message, discord.Message):
            return (
                referenced_message.author.id == self.bot.user.id
            )

        try:

            referenced_message = (
                await message.channel.fetch_message(
                    reference.message_id
                )
            )

            return (
                referenced_message.author.id == self.bot.user.id
            )

        except (
            discord.NotFound,
            discord.Forbidden,
            discord.HTTPException
        ):
            return False

    # --------------------------------------------------
    # TRIGGER DETECTION
    # --------------------------------------------------

    @staticmethod
    def trigger_pattern(trigger: str) -> re.Pattern:

        return re.compile(
            rf"(?<!\w){re.escape(trigger)}(?!\w)",
            re.IGNORECASE
        )

    def extract_trigger(
        self,
        message: discord.Message,
        custom_triggers: list[str]
    ) -> tuple[bool, str]:

        content = message.content
        triggered = False

        # Detect @Aragog mentions.
        if self.bot.user:

            mention_pattern = re.compile(
                rf"<@!?{self.bot.user.id}>"
            )

            if mention_pattern.search(content):
                triggered = True
                content = mention_pattern.sub(" ", content)

        # Detect built-in and custom triggers.
        triggers = list(
            dict.fromkeys(
                self.BUILT_IN_TRIGGERS + tuple(custom_triggers)
            )
        )

        triggers.sort(key=len, reverse=True)

        for trigger in triggers:

            if not trigger:
                continue

            pattern = self.trigger_pattern(trigger)

            if pattern.search(content):
                triggered = True
                content = pattern.sub(" ", content)

        content = re.sub(r"[ \t]{2,}", " ", content)

        content = content.strip(
            " \t\r\n,.:;!?-—"
        )

        return triggered, content

    # --------------------------------------------------
    # AI MESSAGE BUILDING
    # --------------------------------------------------

    async def build_ai_messages(
        self,
        message: discord.Message,
        user_message: str,
        history: list[dict]
    ) -> list[dict]:

        return await ai_engine.build_messages(
            guild_id=(
                message.guild.id
                if message.guild else None
            ),
            user_id=message.author.id,
            user_message=user_message,
            history=history
        )

    @staticmethod
    def extract_answer(response_data: dict) -> str:

        choices = response_data.get("choices", [])

        if not choices:
            raise ValueError("AI returned no response.")

        response_message = choices[0].get("message", {})
        content = response_message.get("content")

        if isinstance(content, list):

            parts = []

            for item in content:

                if isinstance(item, dict):
                    text = item.get("text")

                    if text:
                        parts.append(str(text))

                elif isinstance(item, str):
                    parts.append(item)

            content = "\n".join(parts)

        if not isinstance(content, str) or not content.strip():
            raise ValueError("AI returned an empty response.")

        return content.strip()

    # --------------------------------------------------
    # NORMAL-SIZED RESPONSE FORMATTING
    # --------------------------------------------------

    @staticmethod
    def format_response(content: str) -> str:
        """
        Keep AI response text at normal Discord embed size.
        Remove oversized Markdown heading markers while
        preserving code blocks and ordinary formatting.
        """

        lines = []
        inside_code = False

        for line in content.splitlines():

            stripped = line.strip()

            if stripped.startswith("```"):
                inside_code = not inside_code
                lines.append(line)
                continue

            if not inside_code:
                line = re.sub(
                    r"^\s{0,3}#{1,6}\s+",
                    "",
                    line
                )

            lines.append(line)

        return "\n".join(lines).strip()

    # --------------------------------------------------
    # PREMIUM AI EMBEDS
    # --------------------------------------------------

    def build_ai_embed(
        self,
        message: discord.Message,
        content: str,
        include_user: bool = True
    ) -> discord.Embed:

        formatted_content = self.format_response(content)

        if include_user:

            description = (
                f"{message.author.mention}\n\n"
                f"{formatted_content}"
            )

        else:
            description = formatted_content

        embed = discord.Embed(
            title=self.BRAND,
            description=description,
            color=self.EMBED_COLOR,
            timestamp=datetime.now(timezone.utc)
        )

        if include_user:
            embed.set_thumbnail(
                url=self.bot.user.display_avatar.url
            )

        embed.set_footer(
            text=self.BRAND
        )

        return embed

    # --------------------------------------------------
    # LONG RESPONSE SPLITTING
    # --------------------------------------------------

    @staticmethod
    def split_response(content: str) -> list[str]:

        chunks = []

        while len(content) > AIMessages.MAX_EMBED_CHUNK:

            split_at = content.rfind(
                "\n",
                0,
                AIMessages.MAX_EMBED_CHUNK
            )

            if split_at < AIMessages.MAX_EMBED_CHUNK // 2:

                split_at = content.rfind(
                    " ",
                    0,
                    AIMessages.MAX_EMBED_CHUNK
                )

            if split_at < 1:
                split_at = AIMessages.MAX_EMBED_CHUNK

            chunks.append(
                content[:split_at].strip()
            )

            content = content[split_at:].strip()

        if content:
            chunks.append(content)

        return chunks

    # --------------------------------------------------
    # SEND AI RESPONSE
    # --------------------------------------------------

    async def send_ai_reply(
        self,
        message: discord.Message,
        answer: str
    ):

        chunks = self.split_response(answer)

        for index, chunk in enumerate(chunks):

            embed = self.build_ai_embed(
                message=message,
                content=chunk,
                include_user=(index == 0)
            )

            if index > 0:
                embed.title = "🔥 Aragog • Continued"

            await message.reply(
                embed=embed,
                mention_author=False,
                allowed_mentions=discord.AllowedMentions.none()
            )

    async def send_ai_error(
        self,
        message: discord.Message
    ):

        embed = self.build_ai_embed(
            message,
            "I'm having trouble generating a response right now. Please try again shortly."
        )

        embed.color = 0xED4245

        await message.reply(
            embed=embed,
            mention_author=False,
            allowed_mentions=discord.AllowedMentions.none()
        )

    # --------------------------------------------------
    # MESSAGE EVENT
    # --------------------------------------------------

    @commands.Cog.listener()
    async def on_message(
        self,
        message: discord.Message
    ):

        if message.author.bot:
            return

        try:

            if not await self.is_ai_enabled(message):
                return

            guild_id = (
                message.guild.id
                if message.guild else None
            )

            custom_triggers = await self.get_custom_triggers(
                guild_id
            )

            # Check normal triggers first.
            triggered, user_message = self.extract_trigger(
                message,
                custom_triggers
            )

            # Also respond to direct replies to Aragog.
            if not triggered:

                if await self.is_reply_to_aragog(message):

                    triggered = True
                    user_message = message.content.strip()

            if not triggered:
                return

            if not user_message:

                user_message = (
                    "The user called for you but did not ask "
                    "a question. Reply with a brief, natural "
                    "greeting and ask how you can help."
                )

            # Load conversation history.
            history = await self.load_history(
                guild_id=guild_id,
                channel_id=message.channel.id,
                user_id=message.author.id
            )

            async with message.channel.typing():

                ai_messages = await self.build_ai_messages(
                    message=message,
                    user_message=user_message,
                    history=history
                )

                result = await ai_fallback.generate(
                    messages=ai_messages,
                    guild_id=guild_id,
                    user_id=message.author.id
                )

                if not result.get("success"):

                    await self.send_ai_error(message)
                    return

                answer = self.extract_answer(
                    result["result"]
                )

                # Save conversation for future replies.
                await self.save_exchange(
                    guild_id=guild_id,
                    channel_id=message.channel.id,
                    user_id=message.author.id,
                    user_message=user_message,
                    assistant_message=answer
                )

                await self.send_ai_reply(
                    message,
                    answer
                )

        except Exception as error:

            aragog_logger.error(
                f"AI message handling failed: "
                f"{type(error).__name__}"
            )

            try:
                await self.send_ai_error(message)

            except Exception:
                aragog_logger.error(
                    "Could not send AI error embed."
                )


# --------------------------------------------------
# EXTENSION SETUP
# --------------------------------------------------

async def setup(bot: commands.Bot):

    cog = AIMessages(bot)

    await cog.ensure_storage()
    await bot.add_cog(cog)

    aragog_logger.info(
        "AI listener loaded with normal-sized responses, "
        "reply detection, persistent memory and triggers."
    )
