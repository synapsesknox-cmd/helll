
import discord
from discord.ext import commands

from core.config import Config
from core.database import db
from core.logger import aragog_logger
from core.ai_client import ai_client


class AragogBot(commands.Bot):

    def __init__(self):
        intents = discord.Intents.default()
        intents.guilds = True
        intents.members = True
        intents.message_content = True

        super().__init__(
            command_prefix="!",
            intents=intents,
            help_command=None
        )

    async def setup_hook(self):
        # Initialize database
        await db.initialize()
        aragog_logger.info("Database initialized.")

        # Load extensions
        extensions = [
            "events.ai_messages",
            "commands.triggers",
            "commands.ai_settings",
        ]

        for extension in extensions:
            try:
                await self.load_extension(extension)
                aragog_logger.info(
                    f"Extension loaded: {extension}"
                )

            except Exception as error:
                aragog_logger.error(
                    f"Extension failed: {extension} "
                    f"({type(error).__name__})"
                )
                raise

        # Synchronize slash commands
        synced = await self.tree.sync()

        aragog_logger.info(
            f"Synchronized {len(synced)} Discord commands."
        )

    async def on_ready(self):
        if self.user is None:
            return

        aragog_logger.info(
            f"Logged in as {self.user} (ID: {self.user.id})"
        )

        # Set Aragog to Idle
        await self.change_presence(
    activity=discord.CustomActivity(
        name='Not just your "Normal" Bot 😉'
    ),
    status=discord.Status.idle
)

        aragog_logger.info("Aragog presence set to Idle.")

    async def on_app_command_completion(
        self,
        interaction: discord.Interaction,
        command: discord.app_commands.Command
    ):
        aragog_logger.info(
            f"Command /{command.qualified_name} "
            f"used by {interaction.user.id}"
        )

    async def close(self):
        aragog_logger.info("Shutting down Aragog.")

        await super().close()

        try:
            await ai_client.close()
        except Exception:
            aragog_logger.error("AI client cleanup failed.")

        try:
            await db.close()
        except Exception:
            aragog_logger.error("Database cleanup failed.")


def main():
    try:
        Config.validate()

        bot = AragogBot()
        bot.run(Config.BOT_TOKEN)

    except KeyboardInterrupt:
        aragog_logger.info("Aragog stopped manually.")

    except Exception as error:
        aragog_logger.error(
            f"Aragog startup failed: {type(error).__name__}"
        )
        raise


if __name__ == "__main__":
    main()
