
import time
from core.database import db


class APILogger:

    async def log_request(
        self,
        provider,
        model,
        guild_id=None,
        user_id=None,
        tokens_used=0,
        status="success",
        latency_ms=0
    ):
        await db.execute(
            """
            INSERT INTO api_usage (
                guild_id,
                user_id,
                provider,
                model,
                tokens_used,
                status,
                latency_ms
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                guild_id,
                user_id,
                provider,
                model,
                max(0, int(tokens_used or 0)),
                str(status)[:30],
                max(0, int(latency_ms or 0))
            )
        )

    async def get_server_usage(self, guild_id):
        return await db.fetchone(
            """
            SELECT
                COUNT(*) AS requests,
                COALESCE(SUM(tokens_used), 0) AS total_tokens,
                COALESCE(AVG(latency_ms), 0) AS average_latency
            FROM api_usage
            WHERE guild_id = ?
            """,
            (guild_id,)
        )

    async def get_global_usage(self):
        return await db.fetchone(
            """
            SELECT
                COUNT(*) AS requests,
                COALESCE(SUM(tokens_used), 0) AS total_tokens,
                COALESCE(AVG(latency_ms), 0) AS average_latency
            FROM api_usage
            """
        )

    async def get_provider_usage(self, provider):
        return await db.fetchone(
            """
            SELECT
                COUNT(*) AS requests,
                COALESCE(SUM(tokens_used), 0) AS total_tokens
            FROM api_usage
            WHERE provider = ?
            """,
            (provider,)
        )


api_logger = APILogger()
