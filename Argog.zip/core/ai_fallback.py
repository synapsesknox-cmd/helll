
from core.ai_client import ai_client
from core.api_manager import api_manager
from core.api_logger import api_logger
from core.logger import aragog_logger


class AIFallback:

    async def generate(
        self,
        messages: list,
        guild_id=None,
        user_id=None,
        **options
    ):
        primary_provider = api_manager.get_text_provider()
        fallback_provider = api_manager.get_fallback_provider()

        providers = [primary_provider]

        if fallback_provider != primary_provider:
            providers.append(fallback_provider)

        errors = []

        for provider in providers:
            try:
                api_key = api_manager.get_api_key(
                    provider,
                    category="text"
                )

                model = api_manager.get_text_model(provider)

                if not model:
                    raise RuntimeError(
                        "AI model is not configured."
                    )

                import time
                start_time = time.perf_counter()

                result = await ai_client.chat(
                    provider=provider,
                    api_key=api_key,
                    model=model,
                    messages=messages,
                    **options
                )

                latency = int(
                    (time.perf_counter() - start_time) * 1000
                )

                usage = result.get("usage", {})
                tokens = usage.get("total_tokens", 0)

                await api_logger.log_request(
                    provider=provider,
                    model=model,
                    guild_id=guild_id,
                    user_id=user_id,
                    tokens_used=tokens,
                    status="success",
                    latency_ms=latency
                )

                aragog_logger.info(
    f"AI REQUEST SUCCESS | Provider: {provider} | "
    f"Model: {model} | User: {user_id}"
)

                return {
                    "success": True,
                    "provider": provider,
                    "model": model,
                    "result": result
                }

            except Exception as error:
                errors.append(type(error).__name__)

                aragog_logger.warning(
                    f"AI provider {provider} failed: "
                    f"{type(error).__name__}"
                )

                try:
                    await api_logger.log_request(
                        provider=provider,
                        model="unknown",
                        guild_id=guild_id,
                        user_id=user_id,
                        status="failed"
                    )
                except Exception:
                    aragog_logger.warning(
                        "Could not save API failure log."
                    )

        aragog_logger.error(
            "All configured AI providers failed."
        )

        return {
            "success": False,
            "error": "AI services are temporarily unavailable."
        }


ai_fallback = AIFallback()
