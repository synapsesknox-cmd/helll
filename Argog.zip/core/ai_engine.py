
from core.ai_client import ai_client
from core.database import db
from core.prompts import AragogPrompts


class AIEngine:
    MAX_PROMPT_LENGTH = 4000

    async def get_custom_prompts(self, guild_id, user_id):
        server_prompt = ""
        user_prompt = ""

        if guild_id is not None:
            server = await db.fetchone(
                """
                SELECT custom_prompt
                FROM guild_settings
                WHERE guild_id = ?
                """,
                (guild_id,)
            )

            if server:
                server_prompt = server["custom_prompt"] or ""

        user = await db.fetchone(
            """
            SELECT custom_prompt
            FROM user_settings
            WHERE user_id = ?
            """,
            (user_id,)
        )

        if user:
            user_prompt = user["custom_prompt"] or ""

        return (
            server_prompt[:self.MAX_PROMPT_LENGTH],
            user_prompt[:self.MAX_PROMPT_LENGTH]
        )

    async def build_messages(
        self,
        guild_id,
        user_id,
        user_message,
        history=None
    ):
        server_prompt, user_prompt = await self.get_custom_prompts(
            guild_id,
            user_id
        )

        instructions = AragogPrompts.get_default()

        if server_prompt:
            instructions += (
                "\n\nSERVER PREFERENCES:\n" + server_prompt
            )

        if user_prompt:
            instructions += (
                "\n\nUSER PREFERENCES:\n" + user_prompt
            )

        messages = [
            {
                "role": "system",
                "content": instructions
            }
        ]

        if history:
            for item in history[-10:]:
                role = item.get("role")
                content = item.get("content")

                if role in ("user", "assistant") and isinstance(
                    content, str
                ):
                    messages.append({
                        "role": role,
                        "content": content[:4000]
                    })

        messages.append({
            "role": "user",
            "content": str(user_message)[:8000]
        })

        return messages

    async def ask(
        self,
        guild_id,
        user_id,
        user_message,
        provider,
        api_key,
        model,
        history=None
    ):
        if not isinstance(user_message, str) or not user_message.strip():
            raise ValueError("A message is required.")

        messages = await self.build_messages(
            guild_id,
            user_id,
            user_message,
            history
        )

        result = await ai_client.chat(
            provider=provider,
            api_key=api_key,
            model=model,
            messages=messages
        )

        try:
            answer = result["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            raise RuntimeError("The AI provider returned an invalid response.")

        if isinstance(answer, list):
            answer = "\n".join(
                part.get("text", "")
                for part in answer
                if isinstance(part, dict)
            )

        if not isinstance(answer, str) or not answer.strip():
            raise RuntimeError("The AI provider returned an empty response.")

        return answer.strip()


ai_engine = AIEngine()
