import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    BOT_TOKEN = os.getenv("BOT_TOKEN")

    # Add your Discord numeric User ID to the .env file
    OWNER_ID = int(os.getenv("OWNER_ID", "0"))

    DATABASE_PATH = "data/aragog.db"

    # AI providers
    PRIMARY_TEXT_PROVIDER = "apinex"
    FALLBACK_TEXT_PROVIDER = "openrouter"

    PRIMARY_IMAGE_PROVIDER = "apinex"
    FALLBACK_IMAGE_PROVIDER = "pollinations"

    # API endpoints
    APINEX_BASE_URL = "https://api.apinex.bond/v1"

    # Embed branding
    BOT_NAME = "Aragog"

    @classmethod
    def validate(cls):
        if not cls.BOT_TOKEN:
            raise RuntimeError("Bot configuration is incomplete.")

        if cls.OWNER_ID == 0:
            raise RuntimeError("Owner ID is not configured.")

        return True


def is_owner(user_id: int) -> bool:
    return user_id == Config.OWNER_ID