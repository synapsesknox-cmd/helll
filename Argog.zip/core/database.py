
import aiosqlite
from pathlib import Path

from core.config import Config


class Database:
    def __init__(self):
        self.path = Config.DATABASE_PATH
        self.connection = None

    async def initialize(self):
        """Create the database and required tables."""
        Path(self.path).parent.mkdir(
            parents=True,
            exist_ok=True
        )

        self.connection = await aiosqlite.connect(self.path)
        self.connection.row_factory = aiosqlite.Row

        await self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,
                ai_enabled INTEGER DEFAULT 1,
                ai_channel_id INTEGER,
                custom_prompt TEXT,
                daily_token_budget INTEGER DEFAULT 0,
                image_enabled INTEGER DEFAULT 1,
                api_log_channel_id INTEGER
            );

            CREATE TABLE IF NOT EXISTS user_settings (
                user_id INTEGER PRIMARY KEY,
                custom_prompt TEXT,
                ai_enabled INTEGER DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS bot_bans (
                user_id INTEGER PRIMARY KEY,
                reason TEXT NOT NULL,
                banned_by INTEGER NOT NULL,
                banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                project_name TEXT NOT NULL,
                project_path TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, project_name)
            );

            CREATE TABLE IF NOT EXISTS triggers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                trigger_name TEXT NOT NULL,
                trigger_text TEXT NOT NULL,
                response TEXT NOT NULL,
                enabled INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, trigger_name)
            );

            CREATE TABLE IF NOT EXISTS api_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER,
                user_id INTEGER,
                provider TEXT NOT NULL,
                model TEXT,
                tokens_used INTEGER DEFAULT 0,
                status TEXT,
                latency_ms INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_projects_user
            ON projects(user_id);

            CREATE INDEX IF NOT EXISTS idx_triggers_guild
            ON triggers(guild_id);

            CREATE INDEX IF NOT EXISTS idx_api_usage_guild
            ON api_usage(guild_id);
        """)

        await self.connection.commit()

    async def execute(self, query, parameters=()):
        """Execute a database query."""
        if self.connection is None:
            raise RuntimeError("Database is not initialized.")

        async with self.connection.execute(query, parameters) as cursor:
            await self.connection.commit()
            return cursor.lastrowid

    async def fetchone(self, query, parameters=()):
        """Fetch one database record."""
        if self.connection is None:
            raise RuntimeError("Database is not initialized.")

        async with self.connection.execute(query, parameters) as cursor:
            return await cursor.fetchone()

    async def fetchall(self, query, parameters=()):
        """Fetch multiple database records."""
        if self.connection is None:
            raise RuntimeError("Database is not initialized.")

        async with self.connection.execute(query, parameters) as cursor:
            return await cursor.fetchall()

    async def close(self):
        """Close the database connection."""
        if self.connection is not None:
            await self.connection.close()
            self.connection = None


db = Database()
