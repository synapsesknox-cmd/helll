
import os
from cryptography.fernet import Fernet, InvalidToken


class APISecurity:
    def __init__(self):
        self._fernet = None

    def initialize(self):
        encryption_key = os.getenv("ARAGOG_ENCRYPTION_KEY")

        if not encryption_key:
            raise RuntimeError(
                "API encryption is not configured."
            )

        try:
            self._fernet = Fernet(
                encryption_key.encode("utf-8")
            )
        except (ValueError, TypeError):
            raise RuntimeError(
                "API encryption configuration is invalid."
            ) from None

    def encrypt(self, secret: str) -> str:
        if self._fernet is None:
            self.initialize()

        if not secret or not isinstance(secret, str):
            raise ValueError("Invalid API credential.")

        return self._fernet.encrypt(
            secret.encode("utf-8")
        ).decode("utf-8")

    def decrypt(self, encrypted_secret: str) -> str:
        if self._fernet is None:
            self.initialize()

        try:
            return self._fernet.decrypt(
                encrypted_secret.encode("utf-8")
            ).decode("utf-8")
        except (InvalidToken, ValueError, TypeError):
            raise ValueError(
                "Unable to access the stored credential."
            ) from None

    @staticmethod
    def mask(secret: str) -> str:
        if not secret:
            return "Not configured"

        if len(secret) <= 8:
            return "••••••••"

        return f"{secret[:4]}••••••••{secret[-4:]}"


api_security = APISecurity()
