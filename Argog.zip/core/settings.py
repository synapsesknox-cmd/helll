from core.database import db


class SettingsManager:
    def __init__(self):
        self._initialized = False

    async def initialize(self):
        if self._initialized:
            return

        await db.execute("""
            CREATE TABLE IF NOT EXISTS app_settings (
                scope TEXT NOT NULL,
                scope_id TEXT NOT NULL,
                setting_key TEXT NOT NULL,
                setting_value TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (scope, scope_id, setting_key)
            )
        """)

        self._initialized = True

    async def set(
        self,
        key: str,
        value,
        scope: str = "global",
        scope_id: str = "0"
    ):
        await self.initialize()

        if scope not in ("global", "guild", "user"):
            raise ValueError("Invalid settings scope.")

        await db.execute(
            """
            INSERT INTO app_settings (
                scope,
                scope_id,
                setting_key,
                setting_value
            )
            VALUES (?, ?, ?, ?)
            ON CONFLICT(scope, scope_id, setting_key)
            DO UPDATE SET
                setting_value = excluded.setting_value,
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                scope,
                str(scope_id),
                str(key),
                str(value)
            )
        )

    async def get(
        self,
        key: str,
        default=None,
        scope: str = "global",
        scope_id: str = "0"
    ):
        await self.initialize()

        result = await db.fetchone(
            """
            SELECT setting_value
            FROM app_settings
            WHERE scope = ?
            AND scope_id = ?
            AND setting_key = ?
            """,
            (scope, str(scope_id), str(key))
        )

        return result["setting_value"] if result else default

    async def delete(
        self,
        key: str,
        scope: str = "global",
        scope_id: str = "0"
    ):
        await self.initialize()

        await db.execute(
            """
            DELETE FROM app_settings
            WHERE scope = ?
            AND scope_id = ?
            AND setting_key = ?
            """,
            (scope, str(scope_id), str(key))
        )

    async def get_all(
        self,
        scope: str = "global",
        scope_id: str = "0"
    ):
        await self.initialize()

        results = await db.fetchall(
            """
            SELECT setting_key, setting_value
            FROM app_settings
            WHERE scope = ?
            AND scope_id = ?
            ORDER BY setting_key
            """,
            (scope, str(scope_id))
        )

        return {
            row["setting_key"]: row["setting_value"]
            for row in results
        }


settings = SettingsManager()
