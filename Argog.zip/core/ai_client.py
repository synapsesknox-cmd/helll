
import httpx

from core.config import Config


class AIClient:
    def __init__(self):
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(120.0, connect=15.0),
            follow_redirects=True
        )

    async def chat(
        self,
        provider: str,
        api_key: str,
        model: str,
        messages: list,
        **options
    ):
        providers = {
            "apinex": "https://api.apinex.bond/v1",
            "openrouter": "https://openrouter.ai/api/v1"
        }

        base_url = providers.get(provider.lower())

        if not base_url:
            raise ValueError("Unsupported text provider.")

        if not api_key or not model:
            raise ValueError("AI configuration is incomplete.")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        if provider.lower() == "openrouter":
            headers["HTTP-Referer"] = "https://discord.com"
            headers["X-Title"] = "Aragog"

        payload = {
            "model": model,
            "messages": messages,
            **options
        }

        response = await self.client.post(
            f"{base_url}/chat/completions",
            headers=headers,
            json=payload
        )

        response.raise_for_status()
        return response.json()

    async def generate_image(
        self,
        provider: str,
        api_key: str,
        prompt: str,
        model: str = None
    ):
        provider = provider.lower()

        if provider == "apinex":
            if not api_key:
                raise ValueError("Image configuration is incomplete.")

            headers = {
                "Authorization": f"Bearer {api_key}"
            }

            payload = {
                "prompt": prompt
            }

            if model:
                payload["model"] = model

            response = await self.client.post(
                "https://api.apinex.bond/v1/images/generations",
                headers=headers,
                json=payload
            )

            response.raise_for_status()
            return response.json()

        if provider == "pollinations":
            # Pollinations integration will be configured
            # after its current API documentation is verified.
            raise NotImplementedError(
                "Pollinations image integration is not configured yet."
            )

        raise ValueError("Unsupported image provider.")

    async def close(self):
        await self.client.aclose()


ai_client = AIClient()
