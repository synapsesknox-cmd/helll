
import logging
import discord
from discord import app_commands

from core.embeds import AragogEmbeds


logger = logging.getLogger("Aragog")


class ErrorHandler:

    @staticmethod
    async def send_error(
        interaction: discord.Interaction,
        title: str,
        description: str
    ):
        embed = AragogEmbeds.error(title, description)

        try:
            if interaction.response.is_done():
                await interaction.followup.send(
                    embed=embed,
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    embed=embed,
                    ephemeral=True
                )
        except discord.HTTPException:
            logger.warning(
                "Could not send an error response to interaction."
            )

    @staticmethod
    async def handle_app_command_error(
        interaction: discord.Interaction,
        error: app_commands.AppCommandError
    ):
        if isinstance(error, app_commands.CheckFailure):
            await ErrorHandler.send_error(
                interaction,
                "Access Denied",
                "You don't have permission to use this command."
            )
            return

        if isinstance(error, app_commands.CommandOnCooldown):
            await ErrorHandler.send_error(
                interaction,
                "Slow Down",
                f"Try again in {error.retry_after:.1f} seconds."
            )
            return

        if isinstance(error, app_commands.TransformerError):
            await ErrorHandler.send_error(
                interaction,
                "Invalid Input",
                "One or more command arguments are invalid."
            )
            return

        original_error = getattr(
            error,
            "original",
            error
        )

        logger.error(
            "Unhandled application command error: %s",
            type(original_error).__name__
        )

        await ErrorHandler.send_error(
            interaction,
            "Something Went Wrong",
            "Aragog couldn't complete that request. Please try again later."
        )

    @staticmethod
    def log_internal_error(error: Exception):
        logger.error(
            "Internal error: %s",
            type(error).__name__
        )


error_handler = ErrorHandler()
