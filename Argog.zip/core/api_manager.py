
import os
from dotenv import load_dotenv

load_dotenv()


class APIManager:

    TEXT_PROVIDERS = {
        "apinex": {
            "base_url": "https://api.apinex.bond/v1",
            "key_env": "APINEX_API_KEY",
            "model_env": "APINEX_TEXT_MODEL"
        },
        "openrouter": {
            "base_url": "https://openrouter.ai/api/v1",
            "key_env": "OPENROUTER_API_KEY",
            "model_env": "OPENROUTER_TEXT_MODEL"
        }
    }

    IMAGE_PROVIDERS = {
        "apinex": {
            "key_env": "APINEX_API_KEY"
        },
        "pollinations": {
            "key_env": "POLLINATIONS_API_KEY"
        }
    }

    def get_text_provider(self):
        provider = os.getenv(
            "TEXT_PROVIDER",
            "apinex"
        ).lower().strip()

        if provider not in self.TEXT_PROVIDERS:
            raise ValueError("Invalid text provider.")

        return provider

    def get_image_provider(self):
        provider = os.getenv(
            "IMAGE_PROVIDER",
            "apinex"
        ).lower().strip()

        if provider not in self.IMAGE_PROVIDERS:
            raise ValueError("Invalid image provider.")

        return provider

    def get_api_key(self, provider, category="text"):
        provider = provider.lower().strip()

        providers = (
            self.TEXT_PROVIDERS
            if category == "text"
            else self.IMAGE_PROVIDERS
        )

        config = providers.get(provider)

        if not config:
            raise ValueError("Unsupported API provider.")

        key = os.getenv(config["key_env"], "").strip()

        if not key:
            raise RuntimeError(
                f"{provider} API credentials are not configured."
            )

        return key

    def get_text_model(self, provider=None):
        provider = (
            provider or self.get_text_provider()
        ).lower().strip()

        config = self.TEXT_PROVIDERS.get(provider)

        if not config:
            raise ValueError("Unsupported text provider.")

        model = os.getenv(
            config["model_env"],
            ""
        ).strip()

        if not model:
            raise RuntimeError(
                f"The text model for {provider} is not configured."
            )

        return model

    def get_image_model(self):
        return os.getenv(
            "IMAGE_MODEL",
            ""
        ).strip()

    def get_fallback_provider(self):
        provider = os.getenv(
            "TEXT_FALLBACK_PROVIDER",
            "openrouter"
        ).lower().strip()

        if provider not in self.TEXT_PROVIDERS:
            raise ValueError("Invalid fallback provider.")

        return provider

    def get_provider_url(self, provider):
        config = self.TEXT_PROVIDERS.get(
            provider.lower().strip()
        )

        if not config:
            raise ValueError("Unsupported provider.")

        return config["base_url"]


api_manager = APIManager()
