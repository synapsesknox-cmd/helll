import discord
from datetime import datetime, timezone


class AragogEmbeds:
    BRAND = "Aragog"

    COLORS = {
        "primary": 0x5865F2,
        "success": 0x57F287,
        "error": 0xED4245,
        "warning": 0xFEE75C,
        "info": 0x3498DB,
    }

    @classmethod
    def create(cls, title, description=None, color="primary"):
        embed = discord.Embed(
            title=title,
            description=description,
            color=cls.COLORS.get(color, cls.COLORS["primary"]),
            timestamp=datetime.now(timezone.utc)
        )

        embed.set_footer(text=f"{cls.BRAND} • AI Assistant")
        return embed

    @classmethod
    def success(cls, title, description=None):
        return cls.create(title, description, "success")

    @classmethod
    def error(cls, title, description=None):
        return cls.create(title, description, "error")

    @classmethod
    def warning(cls, title, description=None):
        return cls.create(title, description, "warning")

    @classmethod
    def info(cls, title, description=None):
        return cls.create(title, description, "info")